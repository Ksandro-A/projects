
<?php
error_reporting(E_ALL & ~E_NOTICE);
session_start();


if ($_POST['submit']) {
  include_once("connect.php");
  $username = strip_tags($_POST['username']);
  $password = strip_tags($_POST['password']);

  $sql = "SELECT id, username, password FROM admin WHERE username = '$username' AND password= '$password' ";


  $query = mysqli_query($dbCon, $sql);

  if ($query) {
    $row = mysqli_fetch_row($query);
    $userid = $row[0];
    $dbusername = $row[1];
    $dbpassword = $row[2];

  }

  if ($username == $dbusername && $password == $dbpassword) {
    $_SESSION['username'] = $username;
    $_SESSION['id'] = $userid;
    header('Location: admin.php');
    }else {
      echo "Incorrect username or password";

    }
  
}
?>


<head>
  <title></title>
</head>
<body>

<div align = "center">
<h1>Log in as Admin</h1>
<form method = "post" action = "Adminlogin.php">
<input type = "text" placeholder = "username" name = "username" required = "required" /> <br>
<br>
<input type = "password" placeholder = "password" name = "password" required = "required" /> <br>
<input type = "submit" name = "submit" value = "Submit"/>


</form>

</body>

