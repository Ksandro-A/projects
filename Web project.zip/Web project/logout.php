<?php
error_reporting(E_ALL & ~E_NOTICE);
session_start();
session_destroy();
header('Location:menu.php');
?>
<html>
<head>
	<title>Logout Page</title>
</head>
<body>
>
</body>
</html>

