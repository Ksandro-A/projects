<?php
include_once("connect.php");
$sel_record = $_POST['sel_record'];

$sql = "SELECT * FROM dk WHERE id = '$sel_record'";
	$result = mysqli_query($dbCon, $sql) or die(mysqli_error());
	if (!$result) {
	 	print "<h1>Something has gone wrong!</h1>";
	 } else{
	
	
while ($row = mysqli_fetch_array($result)) {
    $id = $row['id'];
    $username = $_POST['username'];
	$password = $_POST['password'];
    $email = $row['email'];
    $first = $row['first'];
    $last = $row['last'];
    $phone = $row['phone'];
    $cv = $row['cv'];

    $filename = "cvs/$cv";
}

    ?>
    <h2>Modify this information</h2>
    <p>Change what you want then click "Modify Record" button</p>
    <p><doc src = "$filename"></p>

<form id = "myForm" method = "POST" action = "update.php">
<input type = "hidden" name = "id" value = "$id">	
<div>
	<label for = "username">Username*:</label>
	<input type = "text" name = "username" id = "username" required = "required">
</div>
<div>
	<label for = "password">Password*:</label>
	<input type = "password" name = "password" id = "password" required = "required">
</div>
<div>
	<label for = "email">Email*:</label>
	<input type = "text" name = "email" id = "email" value = " $email">
</div>
<div>
	<label for = "first">First Name*:</label>
	<input type = "text" name = "first" id = "first" value = "$first">
</div>
<div>
	<label for = "last">Last Name*:</label>
	<input type = "text" name = "last" id = "last" value = "$last">
</div>
<div>
	<label for = "phone">Phone*:</label>
	<input type = "text" name = "Phone" id = "Phone" value = " $phone">
</div>
<div>
	<label for = "cv">Cv*:</label>
	<input type = "file" name = "upload" id size = "30" = "upload" required = "required">

</div>
<div id = "mySubmit">
	<input type = "submit" name = "submit" value = "Modify">
</div>
</form>
<?php
}
?>