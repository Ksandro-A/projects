<meta name="description" content="A simple photo gallery.">
  <meta name="keywords" content="gallery, photos, upload, browse, images" />
  <meta name="robots" content="all">
  <meta name="viewport" content="width=device-width">
  
  <link href='http://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet' type='text/css'>
  <link rel="stylesheet" href="css/style.css">
  
  <script src="js/libs/modernizr-2.5.3.min.js"></script>
</head>
<body>
  <!-- Prompt IE 6 users to install Chrome Frame. Remove this if you support IE 6.
       chromium.org/developers/how-tos/chrome-frame-getting-started -->
  <!--[if lt IE 7]><p class=chromeframe>Your browser is <em>ancient!</em> <a href="http://browsehappy.com/">Upgrade to a different browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">install Google Chrome Frame</a> to experience this site.</p><![endif]-->
 <div id="wrapper">
  <!-- Header -->
  <header>
  <nav>
    <ul>
     <li><a href="company.php">Company Data</a></li>
     <li><a href="company.php"></a></li>
     <li><a href="student.php"></a></li>
    </ul>
    <span>
      <ul>
      <li><a href="logout.php">Logout</a></li>
     
   </ul>
   </span>
  </nav>
  </header>
  <!-- Content -->
  <div role="main" id="content">
  <body>





<div align = "center">
    <h2>Welcome to the portal where the opportunity awayts</h2>
    <body> You can check in every moment if there anything new has been posted
    </body>
    <h3> Go ahead and check the company sesion<h3>