<meta name="description" content="A simple photo gallery.">
  <meta name="keywords" content="gallery, photos, upload, browse, images" />
  <meta name="robots" content="all">
  <meta name="viewport" content="width=device-width">
  
  <link href='http://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet' type='text/css'>
  <link rel="stylesheet" href="css/style.css">
  
  <script src="js/libs/modernizr-2.5.3.min.js"></script>
</head>
<body>
  <!-- Prompt IE 6 users to install Chrome Frame. Remove this if you support IE 6.
       chromium.org/developers/how-tos/chrome-frame-getting-started -->
  <!--[if lt IE 7]><p class=chromeframe>Your browser is <em>ancient!</em> <a href="http://browsehappy.com/">Upgrade to a different browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">install Google Chrome Frame</a> to experience this site.</p><![endif]-->
 <div id="wrapper">
  <!-- Header -->
  <header>
  <nav>
    <ul>
     <li><a href="home.php">Home</a></li>
     <li><a href="company.php">company</a></li>
     <li><a href="student.php">Feel Free to Post!</a></li>
    </ul>
    <span>
      <ul>
      <li><a href="logout.php">Logout</a></li>
     
   </ul>
   </span>
  </nav>
  </header>
  <!-- Content -->
  <div role="main" id="content">
  <body>











<?php
error_reporting(E_ALL & ~E_NOTICE);
include "connect.php";
$id = $_POST['id'];
  	$username = $_POST['username'];
	$password = $_POST['password'];
    $email = $_POST['email'];
    $first = $_POST['first'];
    $last = $_POST['last'];
    $phone = $_POST['phone'];
    $look = $_POST['look'];


    $sql = "UPDATE dk SET 
    username = '$username',
    password = '$password',
    email = '$email',
    first = '$first',
    last = '$last',
    phone = '$phone',
    look = '$look'
    WHERE id = '$id'";

    $result = mysqli_query($dbCon, $sql) or die (mysqli_error());
    print "<html><head><title>Update Results</title></head></html>";
?>
    <h1>The following has been Updated</h1>
  <ul>
    <li>E-Mail:<?php echo  $email;?></li>
    <li>First Name:<?php echo $first;?></li>
    <li>Last Name:<?php echo $last?></li>
    <li>Phone:<?php echo $phone;?></li>
    <li>Looking For:<?php echo $look;?></li>
    <li>Username:<?php echo $username;?></li>
    <li>Password:<?php echo $password;?></li>
  </ul>

