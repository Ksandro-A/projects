<meta name="description" content="A simple photo gallery.">
  <meta name="keywords" content="gallery, photos, upload, browse, images" />
  <meta name="robots" content="all">
  <meta name="viewport" content="width=device-width">
  
  <link href='http://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet' type='text/css'>
  <link rel="stylesheet" href="css/style.css">
  
  <script src="js/libs/modernizr-2.5.3.min.js"></script>
</head>
<body>
  <!-- Prompt IE 6 users to install Chrome Frame. Remove this if you support IE 6.
       chromium.org/developers/how-tos/chrome-frame-getting-started -->
  <!--[if lt IE 7]><p class=chromeframe>Your browser is <em>ancient!</em> <a href="http://browsehappy.com/">Upgrade to a different browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">install Google Chrome Frame</a> to experience this site.</p><![endif]-->
 <div id="wrapper">
  <!-- Header -->
  <header>
  <nav>
    <ul>
     <li><a href="menu.php">Previous Page</a></li>
     <li><a href="company.php"></a></li>
     <li><a href="student.php"></a></li>
    </ul>
    <span>
      <ul>
      <li><a href="logout.php"></a></li>
     
   </ul>
   </span>
  </nav>
  </header>
  <!-- Content -->
  <div role="main" id="content">
  <body>


























<html>
<h2>Input your Data</h2>
<form id = "myForm" method = "POST" enctype = "multipart/form-data">
	<div>
	<label for = "username">Username*:</label>
	<input type = "text" name = "username" id = "username">
</div>
<div>
	<label for = "password">Password*:</label>
	<input type = "password" name = "password" id = "password">
</div>
<div>
	<label for = "email">Email*:</label>
	<input type = "text" name = "email" id = "email" required = "required">
</div>
<div>
	<label for = "first">First Name*:</label>
	<input type = "text" name = "first" id = "first" required = "required">
</div>
<div>
	<label for = "last">Last Name*:</label>
	<input type = "text" name = "last" id = "last" required = "required">
</div>
<div>
	<label for = "phone">phone*:</label>
	<input type = "text" name = "phone" id = "phone" required = "required">
</div>
<div>
    <label for = "look">Looking For*:</label>
    <input type = "text" name = "look" id = "look" required = "required">
</div>
<div>
	<label for = "cv">Cv*:</label>
	<input type = "file" name = "upload" id size = "30" = "upload">

</div>
<div id = "mySubmit">
	<input type = "submit" name = "submit" value = "Submit">
</div>
</form>
<?php
error_reporting(E_ALL & ~E_NOTICE);
session_start();

  if ($_POST['submit']) {
  	$id = $_POST['id'];
  	$username = $_POST['username'];
	$password = $_POST['password'];
    $email = $_POST['email'];
    $first = $_POST['first'];
    $last = $_POST['last'];
    $phone = $_POST['phone'];
    $look = $_POST['look'];
    

$target_dir = "cvs/";
$target_file = $target_dir . basename($_FILES["upload"]["name"]);
$uploadOk = 1;
$docfiletype = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if image file is a actual image or fake image

    $check = getimagesize($_FILES["upload"]["tmp_name"]);
    if($check !== false) {
        echo "File is a doc - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not a doc.";
        $uploadOk = 0;
    }

// Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}
// Check file size
if ($_FILES["upload"]["size"] > 500000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Allow certain file formats
if($docfiletype != "docx"  ) {
    echo "Sorry, only .docx files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["upload"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["upload"]["name"]). " has been uploaded.";
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}



    include_once("connect.php");
    $sql = "INSERT INTO dk  VALUE (null, '$username', '$password', '$email', '$first', '$last','$phone','$look', '$cv')";
    $result = mysqli_query($dbCon, $sql);
    
    
  
  ?>


  <h1>The following has been added</h1>
  <ul>
    <li><strong>E-Mail:</strong><?php echo  $email;?></li>
    <li><strong>First Name:</strong><?php echo $first;?></li>
    <li><strong>Last Name:</strong><?php echo $last;?></li>
    <li><strong>phone:</strong><?php echo $phone;?></li>
    <li>Looking For:<?php echo $look;?></li>
    <li><strong>Cv File:</strong> <doc src = "cvs/$cv"></li>
  </ul>
  <a href="loginS.php">Click here to log in !</a>
  <?php
}?>