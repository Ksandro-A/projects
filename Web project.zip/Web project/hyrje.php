<?xml version = "1.0" encoding = "utf-8"?>  
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"  
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">  
	<!-- Fig. 5.14: dropdown.html -->  
	<!-- CSS drop-down menu. -->  
	<html xmlns = "http://www.w3.org/1999/xhtml">  
    <head>        <title>         Drop-Down Menu       </title>   
	<style type = "text/css"> 
         	body              { font-family: arial, sans-serif } 
			div.menu          { font-weight: bold; 
			color: white; 
			border: 2px solid #225599; 
			text-align: center; 
			width: 10em; 
			background-color: #225599 } 
	div.menu:hover a  { display: block } 
	div.menu a        { display: none;   
			border-top: 2px solid #225599; 
			background-color: white; 
			width: 10em; 
			text-decoration: none; 
			color: black } 
			div.menu a:hover  { background-color: #dfeeff } 
			</style>     </head>    <body> 
	   <div class = "menu">Menu 
	   <a href = "#">Home</a> 
	   <a href = "#">News</a>          
	   <a href = "#">Articles</a>           <a href = "#">Blog</a> 
	   <a href = "#">Contact</a> 
	   </div>     </body>		</html> 