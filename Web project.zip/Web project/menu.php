<?xml version = "1.0" encoding = "utf-8"?>  
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"  
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">  
	 
	<html xmlns = "http://www.w3.org/1999/xhtml">  
    <head>        <title>         Drop-Down Menu       </title>   
	<style type = "text/css"> 
         	body              { font-family: arial, sans-serif } 
			div.menu          { font-weight: bold; 
			color: white; 
			border: 1px solid #225599; 
			text-align: center; 
			width: 100%; 
			background-color: black; } 
	div.menu:hover a  { display: block } 
	div.menu a        { display: none;   
			border-top: 1px solid #225599; 
			background-color: white; 
			width: 100%; 
			text-decoration: none; 
			color: black } 
			div.menu a:hover  { background-color: #dfeeff } 
			</style>     </head>    <body> 
	   <div class = "menu" align:center>Menu 
	
<a href = "register S.php">Register as student</a>
	  <a href = "loginS.php">Login as student</a>      
	  
	   <a href = "adminlogin.php"> <hi><i> Login as Admin</i></h1> 
	

 <a href = "register C.php">Register as Company</a>
	  <a href = "loginC.php">Login as Company</a>      
	  
	 
	   </div>  

<center> <h1> Welcome to our Website!  </h1>	</center>
<center> <h2> Feel free to post your announcement! </h2></center>
<center>  In the register sesion the username and password is not required. You can fill them if you want to log in!!</center>
<br>
<br>
<br>
<br>
<br>
<div align = "center">
<BASE>Admin Conttact:<a href = "mailto:Admin19@gmail.com">Admin19@gmail.com </BASE>
   </body>		</html> 