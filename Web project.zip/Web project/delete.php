 

<meta name="description" content="A simple photo gallery.">
  <meta name="keywords" content="gallery, photos, upload, browse, images" />
  <meta name="robots" content="all">
  <meta name="viewport" content="width=device-width">
  
  <link href='http://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet' type='text/css'>
  <link rel="stylesheet" href="css/style.css">
  
  <script src="js/libs/modernizr-2.5.3.min.js"></script>
</head>
<body>
  <!-- Prompt IE 6 users to install Chrome Frame. Remove this if you support IE 6.
       chromium.org/developers/how-tos/chrome-frame-getting-started -->
  <!--[if lt IE 7]><p class=chromeframe>Your browser is <em>ancient!</em> <a href="http://browsehappy.com/">Upgrade to a different browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">install Google Chrome Frame</a> to experience this site.</p><![endif]-->
 <div id="wrapper">
  <!-- Header -->
  <header>
  <nav>
    <ul>
     <li><a href="admin.php">Admin</a></li>
     <li><a href="company2.php">company</a></li>
     <li><a href="student2.php">student!</a></li>
    </ul>
    <span>
      <ul>
      <li><a href="logout.php">Logout</a></li>
     
   </ul>
   </span>
  </nav>
  </header>
  <!-- Content -->
  <div role="main" id="content">
  <body>



<h1>Delete Data from Student</h1>


  <?php
  error_reporting(E_ALL & ~E_NOTICE);
if(isset($_POST['delete'])){
    include_once("connect.php");
    $id = $_POST['id'];
    $sql = "DELETE FROM dk WHERE id = '$id'";
    $result = mysqli_query($dbCon, $sql);
    if ($result) {
      echo "Data Deleted";

      }else {
        echo "Data Not Deleted";
      }





}
?>
 <html>
<head>
</head>
<body>
  <form action = "delete.php" method = "post">
    ID TO DELETE:&nbsp;<input type = "text" name = "id" required><br><br>
    <input type = "submit" name = "delete" value = "Clear Data">
  </form>
</body>
</html>








<h1>Delete Data from Companys</h1>
<?php
  error_reporting(E_ALL & ~E_NOTICE);
if(isset($_POST['delete'])){
    include_once("connect.php");
    $id = $_POST['id'];
    $sql = "DELETE FROM com WHERE id = '$id'";
    $result = mysqli_query($dbCon, $sql);
    if ($result) {
      echo "Data Deleted";

      }else {
        echo "Data Not Deleted";
      }





}
?>
 <html>
<head>
</head>
<body>
  <form action = "delete.php" method = "post">
    ID TO DELETE:&nbsp;<input type = "text" name = "id" required><br><br>
    <input type = "submit" name = "delete" value = "Clear Data">
  </form>
</body>
</html>




