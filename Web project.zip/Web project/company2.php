<meta name="description" content="A simple photo gallery.">
  <meta name="keywords" content="gallery, photos, upload, browse, images" />
  <meta name="robots" content="all">
  <meta name="viewport" content="width=device-width">
  
  <link href='http://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet' type='text/css'>
  <link rel="stylesheet" href="css/style.css">
  
  <script src="js/libs/modernizr-2.5.3.min.js"></script>
</head>
<body>
  <!-- Prompt IE 6 users to install Chrome Frame. Remove this if you support IE 6.
       chromium.org/developers/how-tos/chrome-frame-getting-started -->
  <!--[if lt IE 7]><p class=chromeframe>Your browser is <em>ancient!</em> <a href="http://browsehappy.com/">Upgrade to a different browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">install Google Chrome Frame</a> to experience this site.</p><![endif]-->
 <div id="wrapper">
  <!-- Header -->
  <header>
  <nav>
    <ul>
     <li><a href="admin.php">Previous Page</a></li>
     <li><a href="student.php"></a></li>
     <li><a href="student.php"></a></li>
    </ul>
    <span>
      <ul>
      <li><a href="logout.php">Logout</a></li>
     
   </ul>
   </span>
  </nav>
  </header>
  <!-- Content -->
  <div role="main" id="content">
  <body>


















<?php
include_once("connect.php");

 $sql = "SELECT * FROM com ORDER BY last ASC";
    $result = mysqli_query($dbCon, $sql) or die(mysqli_error()); 

?>
<h2>My Info</h2>
Select a record to edit or delete

<?php
while ($row = mysqli_fetch_array($result)) {
    $id = $row['id'];
    $email = $row['email'];
    $first = $row['first'];
    $last = $row['last'];
    $phone = $row['phone'];
    $look = $row['look'];
    $cv = $row['cv'];

    $filename = "cvs/$cv";

?>
<body>
<tr>
    <td>
<form  method = "POST">
<input  type = "hidden" name = "sel_record" value = "$id">
<input  type = "submit" name = "delete" value = "Delete"></form>


<form  method = "POST" action = "updateform.php"> 
<input  type = "hidden" name = "sel_record" value = "$id">
<input type = "submit" name = "update" value = "Edit"></form>

</td>

<h1>Here is the information of <?php echo $first;?></h1>
<ul>
    <li><strong>ID:</strong><?php echo $id ?></li> 
    <li><strong>E-Mail:</strong><?php echo  $email;?></li>
    <li><strong>Company  Name:</strong><?php echo $first;?></li>
    <li><strong>Company Acticity:</strong><?php echo $last;?></li>
    <li><strong>phone:</strong><?php echo $phone;?></li>
    <li><strong>Looking For:</strong><?php echo $look;?></li>
    
</ul>
</body>
<?php
}
?>

